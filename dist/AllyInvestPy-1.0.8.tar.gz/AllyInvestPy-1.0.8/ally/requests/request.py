class Request():
    def __init__(self, response_format):
        self.response_format = response_format

    def execute(self):
        pass
